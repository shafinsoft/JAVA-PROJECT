package GUI;
import Files.*;
import EntityList.*;
import javax.swing.*;
import java.awt.*;
import java.awt.event.*;
import java.awt.image.BufferedImage;
import javax.imageio.ImageIO;
import java.io.*;
import java.util.Scanner;

import GUI.Resource.color.MyColor;


public class LoginPage extends JFrame implements ActionListener {
    private JLabel userNameTFLabel, passwordLabel, loginText,bgColor;
    private JPanel panel, logoPanel;
    private JTextField userNameTF;
    private JPasswordField password;
    private JButton loginButton,Adminsingup;
    File file;
    Scanner sc;

    Font font1 = new Font("Bookman Old Style", Font.BOLD, 20);
    Font font2 = new Font("Bookman Old Style", Font.BOLD, 40);

    public LoginPage() {
		
		//Frame
        super("Login page");
        this.setSize(1300, 700);
		this.setLayout(null);
        this.setLocationRelativeTo(null);
        this.setResizable(false);
        this.setDefaultCloseOperation(EXIT_ON_CLOSE);
		
		
		//Window Icon
        ImageIcon icon = new ImageIcon("GUI/Resource/logo.png"); 									
        Image WImage = icon.getImage();
        this.setIconImage(WImage);
		
		
		//Hospital Images
        ImageIcon i1 = new ImageIcon(ClassLoader.getSystemResource("GUI/Resource/LoginLogo.gif"));
        Image i2 = i1.getImage().getScaledInstance(600, 500, Image.SCALE_DEFAULT);
        ImageIcon i3 = new ImageIcon(i2);
		JLabel background = new JLabel();
		background.setBounds(80, 80, 600, 500);
		background.setIcon(i3);
		this.add(background);
		
		
		//Login button
		loginButton = new JButton("Login");
        loginButton.setBounds(740, 400, 420, 50);
        loginButton.setFont(font1);
        loginButton.setForeground(Color.WHITE);
		loginButton.setBackground(Color.gray);
		loginButton.setFocusable(false);
        loginButton.addActionListener(this);
        this.add(loginButton);
		
        //admin signup
        Adminsingup = new JButton("EXIT");
        Adminsingup.setBounds(740, 480, 420, 50);
        Adminsingup.setFont(font1);
        Adminsingup.setForeground(Color.WHITE);
		Adminsingup.setBackground(Color.gray);
		Adminsingup.setFocusable(false);
        Adminsingup.addActionListener(this);
        this.add(Adminsingup);
	

        //Panel Container
        panel = new JPanel();
		panel.setBounds(700, 80, 500, 500);
		panel.setOpaque(true);
		panel.setBackground(MyColor.blue);
		panel.setLayout(null);
		//this.add(panel);
        

        //Welcome Label
        loginText = new JLabel("Login");
        loginText.setBounds(200, 20, 180, 50);
        loginText.setFont(font2);
        //this.add(loginText);
		

        // USER NAME Label
        userNameTFLabel = new JLabel("User Name:");
        userNameTFLabel.setBounds(40, 100, 200, 30);
        userNameTFLabel.setFont(font1);
        //this.add(userNameTFLabel);

        // USER NAME TextField
        userNameTF = new JTextField();
        userNameTF.setBounds(170, 100, 200, 40);
        userNameTF.setFont(font1);
        //this.add(userNameTF);

        // User Password Label
        passwordLabel = new JLabel("Password:");
        passwordLabel.setBounds(40, 200, 150, 40);
        passwordLabel.setFont(font1);
        //this.add(passwordLabel);

        // User Password Password Field
        password = new JPasswordField();
        password.setBounds(170, 200, 200, 40);
        password.setEchoChar('*');
        password.setFont(font1);
        //this.add(password);

        panel.add(userNameTFLabel);
        panel.add(passwordLabel);
        panel.add(loginText);
        panel.add(password);
        panel.add(userNameTF);
		this.add(panel);

		// frame background
        bgColor = new JLabel("");
        bgColor.setOpaque(true);
        bgColor.setBounds(0, 0, 1300, 700);
        bgColor.setBackground(Color.WHITE);
		this.add(bgColor);
		
        this.setVisible(true);
    }

    public void actionPerformed(ActionEvent e) {
        if (loginButton == e.getSource()) {
            String name = userNameTF.getText();
            String pass = String.valueOf(password.getPassword());

            //System.out.println(name+pass);

        try {
            int i = 0;
            file = new File("Login.txt");
            sc = new Scanner(file);
            while (sc.hasNextLine()) {
                String line = sc.nextLine();
                String line2 = sc.nextLine();
                //System.out.println(line+line2);
                if (name.equals(line) && pass.equals(line2))
                {
                    System.out.println(name+pass);
                    System.out.println(line+line2);
                    i = 1;
                    break;
                }
            }
            if(i == 1) {
                JOptionPane.showMessageDialog(this, "Login Successful");
                
                PatientList patientList = new PatientList(100);
                PatientFileIO.readFromFile("files/patientInfo.txt",patientList);

                DoctorList doctorList = new DoctorList(100);
                DoctorFileIO.readFromFile("files/DoctorInfo.txt",doctorList);

                EmployeeList EmployeeList = new EmployeeList(100);
                EmployeeFileIO.readFromFile("files/EmployeeInfo.txt",EmployeeList);

                new Homepage(this, patientList, doctorList, EmployeeList);
    
                //userNameTF.setText("");
                //password.setText("");
                this.setVisible(false);
				
            }
			
			else{
					JOptionPane.showMessageDialog(this, "Invalid User Name or Password");
				}
        }
        
    
        catch (Exception exp) {
            
            JOptionPane.showMessageDialog(this, "Invalid User Name or Password", 
				  "Error",JOptionPane.ERROR_MESSAGE);
            }
        }
        else if(Adminsingup == e.getSource()){
            int option = JOptionPane.showConfirmDialog(this,"Do you want to EXIT?");
			if(option == JOptionPane.YES_OPTION){
				this.dispose();
				this.setVisible(false);
			}
            
        }
    }
}