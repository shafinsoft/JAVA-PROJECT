package GUI;

import java.awt.Color;
import java.awt.Font;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.io.BufferedWriter;
import java.io.File;
import java.io.FileWriter;

import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JOptionPane;
import javax.swing.JPanel;
import javax.swing.JPasswordField;
import javax.swing.JTextField;

import GUI.Resource.color.MyColor;

public class AdminSignup extends JFrame implements ActionListener{
    private JLabel Password,Name,username,Email,Mobile,singuptext;
    private JPanel panel;
    private JTextField usernameTF,passTF,NameTF,EmailTF,MobileTF;
    //private JPasswordField passwordFD;
    private JButton Signup,Back;
    File file;
    FileWriter writer;
    Font font1 = new Font("Bookman Old Style", Font.BOLD, 25);
    Font font2 = new Font("Bookman Old Style", Font.BOLD, 30);

    public AdminSignup(){
        super("Admin Signup");
        this.setSize(1300, 700);
		this.setLayout(null);
        this.setBackground(Color.black);
        this.setLocationRelativeTo(null);
        this.setResizable(false);
        this.setDefaultCloseOperation(EXIT_ON_CLOSE);
        
        singuptext = new JLabel("Sign Up As An Admin");
        singuptext.setBounds(500, 70, 500, 50);
        singuptext.setFont(font2);
        this.add(singuptext);

        panel = new JPanel();
		panel.setBounds(300, 130,700 , 400);
		panel.setOpaque(true);
		panel.setBackground(MyColor.blue);
		panel.setLayout(null);

        Name = new JLabel("Name:");
        Name.setBounds(150, 30, 200, 30);
        Name.setFont(font2);
        panel.add(Name);

        NameTF = new JTextField();
        NameTF.setBounds(400, 25, 200, 40);
        NameTF.setFont(font1);
        panel.add(NameTF);

        Mobile = new JLabel("NID :");
        Mobile.setBounds(150, 80, 200, 30);
        Mobile.setFont(font2);
        panel.add(Mobile);

        MobileTF = new JTextField();
        MobileTF.setBounds(400, 70, 200, 40);
        MobileTF.setFont(font1);
        panel.add(MobileTF);

        username = new JLabel("User Name:");
        username.setBounds(150, 125, 200, 30);
        username.setFont(font2);
        panel.add(username);

        usernameTF = new JTextField();
        usernameTF.setBounds(400, 120, 200, 40);
        usernameTF.setFont(font1);
        panel.add(usernameTF);

        Password = new JLabel("Password:");
        Password.setBounds(150, 175, 200, 30);
        Password.setFont(font2);
        panel.add(Password);

        passTF = new JTextField();
        passTF.setBounds(400, 170, 200, 40);
        passTF.setFont(font1);
        panel.add(passTF);

        Email = new JLabel("Email:");
        Email.setBounds(150, 220, 200, 30);
        Email.setFont(font2);
        panel.add(Email);

        EmailTF = new JTextField();
        EmailTF.setBounds(400, 215, 200, 40);
        EmailTF.setFont(font1);
        panel.add(EmailTF);


        Signup = new JButton("Signup");
        Signup.setBounds(150, 300, 200, 50);
        Signup.setFont(font1);
        Signup.setForeground(Color.WHITE);
		Signup.setBackground(Color.gray);
		Signup.setFocusable(false);
        Signup.addActionListener(this);
        panel.add(Signup);

        Back = new JButton("Back");
        Back.setBounds(400, 300, 200, 50);
        Back.setFont(font1);
        Back.setForeground(Color.WHITE);
		Back.setBackground(Color.gray);
		Back.setFocusable(false);
        Back.addActionListener(this);
        panel.add(Back);

        this.add(panel);
        this.setVisible(true);
    }

    //@Override
    public void actionPerformed(ActionEvent e) {
        //System.out.println("Done");
        String s1 = usernameTF.getText();
        String s2 = passTF.getText();
        if(Signup == e.getSource()){
            try{
                if(NameTF.getText() == "" || MobileTF.getText() == "" || usernameTF.getText() == "" || passTF.getText() == "" || EmailTF.getText() == ""){
                    JOptionPane.showMessageDialog(this, "Fill Up All The TEXT BOX", 
                      "Error",JOptionPane.ERROR_MESSAGE);
                }
                else{
                file = new File("Login.txt");
                file.createNewFile();
                writer  = new FileWriter(file,true);
                writer.write(s1+"\n");
                writer.write(s2+"\n");
                writer.flush();
                writer.close();
                JOptionPane.showMessageDialog(this, "Regestration Successfull");
                new LoginPage();
                this.setVisible(false);
                }
            }
            catch (Exception exp) {
            JOptionPane.showMessageDialog(this, "Invalid User Name or Password", 
				  "Error",JOptionPane.ERROR_MESSAGE);
            }
        }
    }
        // TODO Auto-generated method stub
        //throw new UnsupportedOperationException("Unimplemented method 'actionPerformed'");
 }
