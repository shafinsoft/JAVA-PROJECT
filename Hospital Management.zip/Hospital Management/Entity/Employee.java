package Entity;
public final class Employee extends Person{
    private String role;

    public Employee(double id,String name, double age, String gender, String role) {
       super(id,name,age,gender);
        this.role = role;
    }	
	
    public void setRole(String role) {
        this.role = role;
    }
    public String getRole() {return role;}

public void showInfo() {
            System.out.println("Employee Name: " + name);
            System.out.println("Employee Age: " + age);
            System.out.println("Employee ID: " + id);
            System.out.println("Employee Gender: " + gender);
			System.out.println("Employee Role: " + role);
    }

}
